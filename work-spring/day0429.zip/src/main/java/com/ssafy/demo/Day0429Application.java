package com.ssafy.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day0429Application {

	public static void main(String[] args) {
		SpringApplication.run(Day0429Application.class, args);
	}

}
