package ver3;

public interface Tire {
	public String getModel();
}
