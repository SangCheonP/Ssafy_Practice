package ver1_2;

public class Color {
	
}
