package ver1_2;

public interface Tire {
	public String getModel();
}
