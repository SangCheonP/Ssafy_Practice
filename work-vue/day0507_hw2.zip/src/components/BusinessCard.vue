<script setup>
const businessCards = [
  { name: "일론 머스크", title: "테슬라 테크노킹" },
  { name: "래리 엘리슨", title: "오라클 창업주" },
  { name: "빌 게이츠", title: "MS 공동창업주" },
  { name: "래리 페이지", title: "구글 공동창업주" },
  { name: "세르게이 브린", title: "구글 공동창업주" },
];

import BusinessCardDetail from "./BusinessCardDetail.vue";
</script>

<template>
  <div class="container">
    <div class="row">
      <!-- v-for을 사용하여 각 카드 데이터를 card prop으로 전달 -->
      <BusinessCardDetail
        class="col-md-4 mb-4"
        v-for="card in businessCards"
        :key="card.name"
        :card="card"
      />
    </div>
  </div>
</template>

<style scoped>
.container {
  max-width: 960px; /* 최대 너비 설정 (Bootstrap 기본값 참고) */
  display: flex; /* Flexbox를 활용한 중앙 정렬 */
  flex-wrap: wrap; /* 요소들이 다음 줄로 넘어갈 수 있도록 설정 */
  justify-content: center; /* 중앙 정렬 */
}
</style>
