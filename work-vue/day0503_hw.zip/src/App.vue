<script setup>
import MyComponent from './components/MyComponent.vue';
</script>

<template>
  <MyComponent></MyComponent>
</template>

<style scoped>
</style>
