<script setup>
import {ref} from "vue";
import MyComponentCard from './MyComponentCard.vue';

const numberOfItems = ref(4);
</script>

<template>
  <div>
    <header>
      <h1>My Gallery</h1>
    </header>
    <main>
      <div class="container">
        <div class="row justify-content">
            <MyComponentCard v-for="n in numberOfItems" :key="n"/>
        </div>
      </div>
    </main>
  </div>
</template>

<style scoped>
header {
  text-align: center;
  background-color: aquamarine;
  padding: 25px 0px;
}

h1 {
  font-size: 60px;
  font-weight: bold;
}

</style>
